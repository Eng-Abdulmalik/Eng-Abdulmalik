### Machine Learning for Engineers: [AdditiveManufacturing](https://www.apmonitor.com/pds/index.php/Main/AdditiveManufacturing)
- [Additive Manufacturing](https://www.apmonitor.com/pds/index.php/Main/AdditiveManufacturing)
 - Source Blocks: 1
 - Description: Machine learning to predict additive manufacturing product properties with PLA and ABS in a grid or honeycomb design.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
