### Machine Learning for Engineers: [WindPower](https://www.apmonitor.com/pds/index.php/Main/WindPower)
- [Wind Power](https://www.apmonitor.com/pds/index.php/Main/WindPower)
 - Source Blocks: 1
 - Description: Predict wind power from time series data.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
