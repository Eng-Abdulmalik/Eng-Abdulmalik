mapping = {'Cat': 0, 'Dog': 1}
data['Label'] = data['Type'].replace(mapping)