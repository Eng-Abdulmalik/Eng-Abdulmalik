# Ordinal number encoding
data['CNumber'] = pd.factorize(data['Color'])[0]