data.set_index('Time',inplace=True)
data['log_time'].plot()