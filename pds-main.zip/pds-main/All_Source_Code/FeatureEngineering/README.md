### Machine Learning for Engineers: [FeatureEngineering](https://www.apmonitor.com/pds/index.php/Main/FeatureEngineering)
- [Feature Engineering](https://www.apmonitor.com/pds/index.php/Main/FeatureEngineering)
 - Source Blocks: 9
 - Description: Feature engineering is the process of selecting and creating the input descriptors for machine learning.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
