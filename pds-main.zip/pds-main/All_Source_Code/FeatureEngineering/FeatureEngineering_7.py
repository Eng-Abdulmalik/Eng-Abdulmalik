data = data.join(pd.get_dummies(data['Color']))
data.head()