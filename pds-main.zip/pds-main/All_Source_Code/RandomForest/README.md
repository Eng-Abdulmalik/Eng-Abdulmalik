### Machine Learning for Engineers: [RandomForest](https://www.apmonitor.com/pds/index.php/Main/RandomForest)
- [Random Forest](https://www.apmonitor.com/pds/index.php/Main/RandomForest)
 - Source Blocks: 2
 - Description: Introduction to Random Forest
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
