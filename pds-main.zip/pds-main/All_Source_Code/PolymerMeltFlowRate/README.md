### Machine Learning for Engineers: [PolymerMeltFlowRate](https://www.apmonitor.com/pds/index.php/Main/PolymerMeltFlowRate)
- [Polymer Melt Flow Rate](https://www.apmonitor.com/pds/index.php/Main/PolymerMeltFlowRate)
 - Source Blocks: 0
 - Description: Polymer properties such as density, melt index, and melt flow rate must be kept within tight specifications for each grade. This case study is to analyze polymer production data to predict melt flow rate.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
