### Machine Learning for Engineers: [ThermophysicalProperties](https://www.apmonitor.com/pds/index.php/Main/ThermophysicalProperties)
- [Thermophysical Properties](https://www.apmonitor.com/pds/index.php/Main/ThermophysicalProperties)
 - Source Blocks: 1
 - Description: Predict parachor values from group contribution methods. Parachor values are a factor in the prediction of several thermophysical properties such as surface tension and thermal conductivity.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
