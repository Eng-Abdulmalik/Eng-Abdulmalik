name='image'
cv.imshow(name,im)
cv.namedWindow(name, cv.WINDOW_AUTOSIZE)
cv.waitKey(0) # waits for key press
cv.destroyAllWindows() 