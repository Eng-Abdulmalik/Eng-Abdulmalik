### Machine Learning for Engineers: [ComputerVisionIntro](https://www.apmonitor.com/pds/index.php/Main/ComputerVisionIntro)
- [Computer Vision Introduction](https://www.apmonitor.com/pds/index.php/Main/ComputerVisionIntro)
 - Source Blocks: 13
 - Description: Computer vision is how computers automate tasks that mimic human response to visual information. Computers gain high-level understanding and take actions from digital images or videos.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
