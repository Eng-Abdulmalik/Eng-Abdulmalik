import matplotlib.pyplot as plt
im2 = plt.imread('students_walking.jpg')
plt.imshow(im2)