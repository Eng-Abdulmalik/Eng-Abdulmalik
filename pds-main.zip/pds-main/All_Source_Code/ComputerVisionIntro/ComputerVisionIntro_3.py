import cv2 as cv
im = cv.imread('students_walking.jpg')