### Machine Learning for Engineers: [MultilayerPerceptronNeuralNetwork](https://www.apmonitor.com/pds/index.php/Main/MultilayerPerceptronNeuralNetwork)
- [Deep Learning](https://www.apmonitor.com/pds/index.php/Main/MultilayerPerceptronNeuralNetwork)
 - Source Blocks: 9
 - Description: Deep learning is a type of machine learning with a multi-layered neural network. It is one of many machine learning methods for synthesizing data into a predictive form.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
