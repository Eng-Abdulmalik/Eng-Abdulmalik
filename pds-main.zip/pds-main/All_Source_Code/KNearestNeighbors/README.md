### Machine Learning for Engineers: [KNearestNeighbors](https://www.apmonitor.com/pds/index.php/Main/KNearestNeighbors)
- [k-Nearest Neighbors Classifier](https://www.apmonitor.com/pds/index.php/Main/KNearestNeighbors)
 - Source Blocks: 3
 - Description: Introduction to K-Nearest Neighbors for Classification.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
