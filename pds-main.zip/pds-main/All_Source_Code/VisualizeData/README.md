### Machine Learning for Engineers: [VisualizeData](https://www.apmonitor.com/pds/index.php/Main/VisualizeData)
- [Data Visualization and Exploration](https://www.apmonitor.com/pds/index.php/Main/VisualizeData)
 - Source Blocks: 15
 - Description: Data visualization and exploration is one of the first steps in machine learning after the data is gathered and summarized with statistics. It is used to graphically represent data to qualitatively understand relationships and data quality.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
