import seaborn as sns
sns.pairplot(data)