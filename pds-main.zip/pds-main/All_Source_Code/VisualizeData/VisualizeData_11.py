import plotly.express as px
fig = px.scatter(data, x="Q1", y="T1")
fig.show()