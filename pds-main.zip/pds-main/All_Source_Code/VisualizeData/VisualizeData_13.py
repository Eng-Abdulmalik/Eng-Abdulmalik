import seaborn as sns
sns.heatmap(data.corr())