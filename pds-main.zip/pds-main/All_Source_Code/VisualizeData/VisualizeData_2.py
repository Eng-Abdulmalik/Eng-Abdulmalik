%%javascript
IPython.OutputArea.auto_scroll_threshold = 9999