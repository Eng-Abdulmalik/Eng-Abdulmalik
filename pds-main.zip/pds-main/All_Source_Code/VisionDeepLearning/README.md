### Machine Learning for Engineers: [VisionDeepLearning](https://www.apmonitor.com/pds/index.php/Main/VisionDeepLearning)
- [Computer Vision with Deep Learning](https://www.apmonitor.com/pds/index.php/Main/VisionDeepLearning)
 - Source Blocks: 2
 - Description: Computer vision is how computers automate tasks that mimic human response to visual information. Image features such as points, edges, or objects are used to identify an object in an image with Deep Learning.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
