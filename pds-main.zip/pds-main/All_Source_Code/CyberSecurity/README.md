### Machine Learning for Engineers: [CyberSecurity](https://www.apmonitor.com/pds/index.php/Main/CyberSecurity)
- [OT Cybersecurity](https://www.apmonitor.com/pds/index.php/Main/CyberSecurity)
 - Source Blocks: 0
 - Description: Operational Technology (OT) Cybersecurity ensure reliable and safe operation of devices that control the physical world. Machine learning is one tool to detect threats to OT infrastructure.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
