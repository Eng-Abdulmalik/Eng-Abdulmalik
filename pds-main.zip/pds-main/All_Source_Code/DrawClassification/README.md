### Machine Learning for Engineers: [DrawClassification](https://www.apmonitor.com/pds/index.php/Main/DrawClassification)
- [Draw Classification](https://www.apmonitor.com/pds/index.php/Main/DrawClassification)
 - Source Blocks: 1
 - Description: Draw Data for Supervised Learning
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
