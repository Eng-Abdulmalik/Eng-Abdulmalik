### Machine Learning for Engineers: [TextureClassification](https://www.apmonitor.com/pds/index.php/Main/TextureClassification)
- [Texture Classification](https://www.apmonitor.com/pds/index.php/Main/TextureClassification)
 - Source Blocks: 0
 - Description: Image features such as points, edges, or objects are used to identify an object in an image. One way to do material classification is by using local binary patterns to detect textures.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
