from pip._internal import main as pipmain
pipmain(['install','gekko'])