### Machine Learning for Engineers: [InstallPythonPackages](https://www.apmonitor.com/pds/index.php/Main/InstallPythonPackages)
- [Install Python Data Science Packages](https://www.apmonitor.com/pds/index.php/Main/InstallPythonPackages)
 - Source Blocks: 20
 - Description: Install Python packages to use data science and machine learning. The power of Python is in the packages that are available either through the pip or conda package managers.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
