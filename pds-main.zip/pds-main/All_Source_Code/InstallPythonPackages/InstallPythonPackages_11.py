pip install pandas-profiling[notebook]
jupyter nbextension enable --py widgetsnbextension