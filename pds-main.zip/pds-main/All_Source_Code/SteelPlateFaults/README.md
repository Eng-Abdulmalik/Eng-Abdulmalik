### Machine Learning for Engineers: [SteelPlateFaults](https://www.apmonitor.com/pds/index.php/Main/SteelPlateFaults)
- [Steel Plate Defects](https://www.apmonitor.com/pds/index.php/Main/SteelPlateFaults)
 - Source Blocks: 9
 - Description: Machine learning to predict defects (faults) in a steel plate. There are multiple types of faults or a general other type of fault for defects that do not fit into one of the categories.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
