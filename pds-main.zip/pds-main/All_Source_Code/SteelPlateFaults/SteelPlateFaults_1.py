import pandas as pd
url = 'http://apmonitor.com/pds/uploads/Main/steel.txt'
data = pd.read_csv(url)