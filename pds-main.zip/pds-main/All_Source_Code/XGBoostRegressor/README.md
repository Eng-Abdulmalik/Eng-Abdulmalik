### Machine Learning for Engineers: [XGBoostRegressor](https://www.apmonitor.com/pds/index.php/Main/XGBoostRegressor)
- [XGBoost Regressor](https://www.apmonitor.com/pds/index.php/Main/XGBoostRegressor)
 - Source Blocks: 2
 - Description: Introduction to XGBoost for Regression
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
