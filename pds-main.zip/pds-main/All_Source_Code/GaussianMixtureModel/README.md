### Machine Learning for Engineers: [GaussianMixtureModel](https://www.apmonitor.com/pds/index.php/Main/GaussianMixtureModel)
- [Gaussian Mixture Model](https://www.apmonitor.com/pds/index.php/Main/GaussianMixtureModel)
 - Source Blocks: 1
 - Description: Introduction to Gaussian Mixture Models
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
