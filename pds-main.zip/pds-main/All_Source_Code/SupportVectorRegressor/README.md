### Machine Learning for Engineers: [SupportVectorRegressor](https://www.apmonitor.com/pds/index.php/Main/SupportVectorRegressor)
- [Support Vector Regressor](https://www.apmonitor.com/pds/index.php/Main/SupportVectorRegressor)
 - Source Blocks: 1
 - Description: Introduction to Support Vector Machine for Regression
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
