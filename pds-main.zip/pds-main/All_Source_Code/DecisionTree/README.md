### Machine Learning for Engineers: [DecisionTree](https://www.apmonitor.com/pds/index.php/Main/DecisionTree)
- [Decision Tree](https://www.apmonitor.com/pds/index.php/Main/DecisionTree)
 - Source Blocks: 4
 - Description: Introduction to Decision Tree
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
