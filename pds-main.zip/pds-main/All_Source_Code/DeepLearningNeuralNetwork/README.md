### Machine Learning for Engineers: [DeepLearningNeuralNetwork](https://www.apmonitor.com/pds/index.php/Main/DeepLearningNeuralNetwork)
- [Deep Learning Neural Network](https://www.apmonitor.com/pds/index.php/Main/DeepLearningNeuralNetwork)
 - Source Blocks: 2
 - Description: Introduction to Deep Learning Neural Networks
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
