### Machine Learning for Engineers: [TCLabIntro](https://www.apmonitor.com/pds/index.php/Main/TCLabIntro)
- [Data Science with the TCLab](https://www.apmonitor.com/pds/index.php/Main/TCLabIntro)
 - Source Blocks: 0
 - Description: Temperature Control Lab (TCLab): Data science modules for hands-on learning with real data.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
