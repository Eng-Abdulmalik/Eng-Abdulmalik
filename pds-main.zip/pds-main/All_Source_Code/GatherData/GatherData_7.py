d = np.loadtxt('dx.csv',delimiter=',',skiprows=1)
print(d)