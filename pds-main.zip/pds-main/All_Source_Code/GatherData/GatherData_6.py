d = np.genfromtxt('dx.csv',delimiter=',')
print(d)