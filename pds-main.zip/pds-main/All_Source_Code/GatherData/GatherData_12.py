from bs4 import BeautifulSoup
soup = BeautifulSoup(page.content, 'html.parser')