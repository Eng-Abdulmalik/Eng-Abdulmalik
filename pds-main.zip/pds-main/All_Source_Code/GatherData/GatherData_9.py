f = open('dx.csv', 'r')
x = f.read(4); print(x)
f.close()