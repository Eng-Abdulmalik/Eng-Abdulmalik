# local source
pd.read_csv('dx.csv')