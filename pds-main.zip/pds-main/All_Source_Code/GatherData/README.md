### Machine Learning for Engineers: [GatherData](https://www.apmonitor.com/pds/index.php/Main/GatherData)
- [Data Gathering and Consolidation](https://www.apmonitor.com/pds/index.php/Main/GatherData)
 - Source Blocks: 23
 - Description: Gathering data tutorials in Python for consolidating disparate data (Excel spreadsheet, CSV file, PDF report, database, cloud storage) into a single repository.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
