f = open('dx.csv', 'r')
for x in f:
  print(x)
f.close()