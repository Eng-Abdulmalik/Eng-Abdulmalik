dx = dx.set_index('Time')
dy = dy.set_index('Time')