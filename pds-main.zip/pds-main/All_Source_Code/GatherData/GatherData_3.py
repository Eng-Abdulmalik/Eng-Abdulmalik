# online source
pd.read_csv('http://apmonitor.com/pds/uploads/Main/dx.txt')