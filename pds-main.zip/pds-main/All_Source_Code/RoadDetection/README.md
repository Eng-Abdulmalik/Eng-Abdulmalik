### Machine Learning for Engineers: [RoadDetection](https://www.apmonitor.com/pds/index.php/Main/RoadDetection)
- [Road Detection](https://www.apmonitor.com/pds/index.php/Main/RoadDetection)
 - Source Blocks: 1
 - Description: Use OpenCV in Python to split frames from a video into hue, saturation, and intensity to create a filter that accentuates the road path for a self-driving vehicle.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
