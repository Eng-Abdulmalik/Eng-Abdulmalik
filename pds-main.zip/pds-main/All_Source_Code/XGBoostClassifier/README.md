### Machine Learning for Engineers: [XGBoostClassifier](https://www.apmonitor.com/pds/index.php/Main/XGBoostClassifier)
- [XGBoost Classifier](https://www.apmonitor.com/pds/index.php/Main/XGBoostClassifier)
 - Source Blocks: 3
 - Description: Introduction to Support Vector Classifier
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
