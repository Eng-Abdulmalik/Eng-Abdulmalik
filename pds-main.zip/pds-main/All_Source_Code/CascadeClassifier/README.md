### Machine Learning for Engineers: [CascadeClassifier](https://www.apmonitor.com/pds/index.php/Main/CascadeClassifier)
- [Computer Vision with Cascade Classifier](https://www.apmonitor.com/pds/index.php/Main/CascadeClassifier)
 - Source Blocks: 3
 - Description: Computer vision is how computers automate tasks that mimic human response to visual information. Image features such as points, edges, or objects are used to identify an object in an image.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
