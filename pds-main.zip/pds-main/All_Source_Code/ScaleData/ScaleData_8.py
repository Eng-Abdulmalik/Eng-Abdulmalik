print('Scaler multipliers')
print('a: ', s.scale_)
print('Scaler minimum')
print('b: ', s.min_)