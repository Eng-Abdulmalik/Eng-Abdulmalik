### Machine Learning for Engineers: [ScaleData](https://www.apmonitor.com/pds/index.php/Main/ScaleData)
- [Scale Data for Machine Learning](https://www.apmonitor.com/pds/index.php/Main/ScaleData)
 - Source Blocks: 13
 - Description: Scaling data to a range of 0 to 1 can improves machine learning performance for certain algorithms such as neural networks.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
