from sklearn.preprocessing import StandardScaler
s = StandardScaler()
s_train = s.fit_transform(train)