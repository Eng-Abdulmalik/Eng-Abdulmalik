print('a: ', s.scale_)
print('Scaler mean')
print('b: ', s.mean_)