### Machine Learning for Engineers: [LinearRegression](https://www.apmonitor.com/pds/index.php/Main/LinearRegression)
- [Linear Regression](https://www.apmonitor.com/pds/index.php/Main/LinearRegression)
 - Source Blocks: 4
 - Description: Perform univariate and multivariate linear regression with Python with and without parameter constraints.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
