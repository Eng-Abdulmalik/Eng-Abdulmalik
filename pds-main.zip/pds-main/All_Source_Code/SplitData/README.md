### Machine Learning for Engineers: [SplitData](https://www.apmonitor.com/pds/index.php/Main/SplitData)
- [Split Data: Train, Validate, Test](https://www.apmonitor.com/pds/index.php/Main/SplitData)
 - Source Blocks: 3
 - Description: Splitting data ensures that there are independent sets for training, testing, and validation.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
