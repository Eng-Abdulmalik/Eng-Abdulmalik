### Machine Learning for Engineers: [AutomotiveMonitoring](https://www.apmonitor.com/pds/index.php/Main/AutomotiveMonitoring)
- [Automotive Monitoring](https://www.apmonitor.com/pds/index.php/Main/AutomotiveMonitoring)
 - Source Blocks: 1
 - Description: Machine learning project with automotive data. Data includes travel distance, time, fuel rate, air flow, oxygen ratio, and other parameters available from an OBD2 interface.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
