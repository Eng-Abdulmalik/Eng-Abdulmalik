### Machine Learning for Engineers: [LogisticRegression](https://www.apmonitor.com/pds/index.php/Main/LogisticRegression)
- [Logistic Regression](https://www.apmonitor.com/pds/index.php/Main/LogisticRegression)
 - Source Blocks: 7
 - Description: Introduction to Logistic Regression
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
