### Machine Learning for Engineers: [NaiveBayes](https://www.apmonitor.com/pds/index.php/Main/NaiveBayes)
- [Naive Bayes](https://www.apmonitor.com/pds/index.php/Main/NaiveBayes)
 - Source Blocks: 2
 - Description: Introduction to Naive Bayes
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
