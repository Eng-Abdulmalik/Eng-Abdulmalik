for x in faces:
    print(x['confidence'])