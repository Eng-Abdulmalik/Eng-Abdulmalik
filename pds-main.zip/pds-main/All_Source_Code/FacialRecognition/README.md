### Machine Learning for Engineers: [FacialRecognition](https://www.apmonitor.com/pds/index.php/Main/FacialRecognition)
- [Facial Recognition](https://www.apmonitor.com/pds/index.php/Main/FacialRecognition)
 - Source Blocks: 8
 - Description: Use computer vision and deep learning to detect faces, recognize the class participant, record attendance, and send a customized message to students who missed class that day.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
