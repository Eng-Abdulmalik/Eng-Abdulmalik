### Machine Learning for Engineers: [StatisticsMath](https://www.apmonitor.com/pds/index.php/Main/StatisticsMath)
- [Summary Statistics](https://www.apmonitor.com/pds/index.php/Main/StatisticsMath)
 - Source Blocks: 4
 - Description: Summary statistics are one of the first steps in data science and machine learning after the data is gathered. It is used to assess data quality and diversity.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
