### Machine Learning for Engineers: [ARXTimeSeries](https://www.apmonitor.com/pds/index.php/Main/ARXTimeSeries)
- [ARX Time Series Model](https://www.apmonitor.com/pds/index.php/Main/ARXTimeSeries)
 - Source Blocks: 3
 - Description: Autoregressive exogenous models are a linear representation of a dynamic system in discrete form. Examples show how to use a time series model in APMonitor, Python GEKKO, and Python Numpy.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
