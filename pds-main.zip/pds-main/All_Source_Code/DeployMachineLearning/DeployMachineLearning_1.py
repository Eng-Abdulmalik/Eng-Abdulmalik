z = [1,2,3]

import pickle
pickle.dump(z,open('z.pkl','wb'))