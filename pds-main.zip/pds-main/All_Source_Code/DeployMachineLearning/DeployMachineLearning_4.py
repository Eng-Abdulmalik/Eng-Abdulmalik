from keras.models import load_model
model = load_model('store.h5')