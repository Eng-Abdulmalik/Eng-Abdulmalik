import pickle
y = pickle.load(open('z.pkl','rb'))
print(y)