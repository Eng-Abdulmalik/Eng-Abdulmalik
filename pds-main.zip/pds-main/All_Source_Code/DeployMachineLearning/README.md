### Machine Learning for Engineers: [DeployMachineLearning](https://www.apmonitor.com/pds/index.php/Main/DeployMachineLearning)
- [Deploy Machine Learning](https://www.apmonitor.com/pds/index.php/Main/DeployMachineLearning)
 - Source Blocks: 10
 - Description: Deploying machine learning is the process of making the machine learning solution available to produce results for people or computers to access the service remotely.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
