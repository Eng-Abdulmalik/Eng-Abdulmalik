### Machine Learning for Engineers: [ActuatorMonitor](https://www.apmonitor.com/pds/index.php/Main/ActuatorMonitor)
- [IOT/OT Cybersecurity](https://www.apmonitor.com/pds/index.php/Main/ActuatorMonitor)
 - Source Blocks: 4
 - Description: Cyberattacks on infrastructure are increasingly common. This case study uses a microcontroller with sensors and actuators (TCLab) to learn if a heater is on or off and whether that agrees with the commanded signal
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
