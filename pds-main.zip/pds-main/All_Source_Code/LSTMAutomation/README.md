### Machine Learning for Engineers: [LSTMAutomation](https://www.apmonitor.com/pds/index.php/Main/LSTMAutomation)
- [Automation with LSTM Network](https://www.apmonitor.com/pds/index.php/Main/LSTMAutomation)
 - Source Blocks: 2
 - Description: Automate a temperature control process with an LSTM (Long Short Term Memory) network that emulates a PID (Proportional Integral Derivative) controller or Model Predictive Controller (MPC).
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
