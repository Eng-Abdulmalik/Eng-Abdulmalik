### Machine Learning for Engineers: [InstallPython](https://www.apmonitor.com/pds/index.php/Main/InstallPython)
- [Install Python and Data Science Packages](https://www.apmonitor.com/pds/index.php/Main/InstallPython)
 - Source Blocks: 0
 - Description: Install Python and packages to use data science and machine learning. The power of Python is in the packages that are available either through the pip or conda package managers.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
