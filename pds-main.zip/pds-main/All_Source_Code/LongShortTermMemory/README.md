### Machine Learning for Engineers: [LongShortTermMemory](https://www.apmonitor.com/pds/index.php/Main/LongShortTermMemory)
- [LSTM Networks](https://www.apmonitor.com/pds/index.php/Main/LongShortTermMemory)
 - Source Blocks: 10
 - Description: Long-Short Term Memory (LSTM), Recurrent Neural Networks, and other sequential processing methods consider a window of data to make a future prediction.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
