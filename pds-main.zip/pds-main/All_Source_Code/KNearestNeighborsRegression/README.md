### Machine Learning for Engineers: [KNearestNeighborsRegression](https://www.apmonitor.com/pds/index.php/Main/KNearestNeighborsRegression)
- [k-Nearest Neighbors Regression](https://www.apmonitor.com/pds/index.php/Main/KNearestNeighborsRegression)
 - Source Blocks: 1
 - Description: Introduction to K-Nearest Neighbors for regression
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
