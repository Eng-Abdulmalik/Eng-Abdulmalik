### Machine Learning for Engineers: [LithiumIonBatteries](https://www.apmonitor.com/pds/index.php/Main/LithiumIonBatteries)
- [Lithium-ion Batteries](https://www.apmonitor.com/pds/index.php/Main/LithiumIonBatteries)
 - Source Blocks: 1
 - Description: Properties of Lithium-ion silicate to predict the crystal structure of the battery.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
