### Machine Learning for Engineers: [ImbalancedData](https://www.apmonitor.com/pds/index.php/Main/ImbalancedData)
- [Imbalanced Data and Learning](https://www.apmonitor.com/pds/index.php/Main/ImbalancedData)
 - Source Blocks: 6
 - Description: Identify imbalanced data and use undersampling or oversampling to improve the machine learning classification results.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
