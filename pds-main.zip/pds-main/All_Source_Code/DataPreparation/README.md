### Machine Learning for Engineers: [DataPreparation](https://www.apmonitor.com/pds/index.php/Main/DataPreparation)
- [Data Engineering](https://www.apmonitor.com/pds/index.php/Main/DataPreparation)
 - Source Blocks: 0
 - Description: Data preparation includes steps such as consolidation, visualization, cleansing, tokenizing, scaling, and splitting the data into sets for training, validation, and testing.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
