### Machine Learning for Engineers: [ClassificationOverview](https://www.apmonitor.com/pds/index.php/Main/ClassificationOverview)
- [Classification with Machine Learning](https://www.apmonitor.com/pds/index.php/Main/ClassificationOverview)
 - Source Blocks: 5
 - Description: Supervised and unsupervised machine learning methods make a classification decision based on feature inputs.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
