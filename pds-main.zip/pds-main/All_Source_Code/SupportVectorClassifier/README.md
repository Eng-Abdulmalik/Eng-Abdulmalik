### Machine Learning for Engineers: [SupportVectorClassifier](https://www.apmonitor.com/pds/index.php/Main/SupportVectorClassifier)
- [Support Vector Classifier](https://www.apmonitor.com/pds/index.php/Main/SupportVectorClassifier)
 - Source Blocks: 2
 - Description: Introduction to Support Vector Classifier
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
