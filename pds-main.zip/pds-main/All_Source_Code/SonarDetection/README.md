### Machine Learning for Engineers: [SonarDetection](https://www.apmonitor.com/pds/index.php/Main/SonarDetection)
- [Sonar Detection](https://www.apmonitor.com/pds/index.php/Main/SonarDetection)
 - Source Blocks: 1
 - Description: Sonar data for detection of pipe versus rock.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
