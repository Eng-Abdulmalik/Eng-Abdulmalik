### Machine Learning for Engineers: [CleanseData](https://www.apmonitor.com/pds/index.php/Main/CleanseData)
- [Data Cleansing](https://www.apmonitor.com/pds/index.php/Main/CleanseData)
 - Source Blocks: 7
 - Description: Measurements from sensors or from human input can contain bad data that negatively affects machine learning. This tutorial demonstrates how to identify and remove bad data.
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
