### Machine Learning for Engineers: [StochasticGradientDescent](https://www.apmonitor.com/pds/index.php/Main/StochasticGradientDescent)
- [Stochastic Gradient Descent](https://www.apmonitor.com/pds/index.php/Main/StochasticGradientDescent)
 - Source Blocks: 2
 - Description: Introduction to Stochastic Gradient Descent
- [Course Overview](https://apmonitor.com/pds)
- [Course Schedule](https://apmonitor.com/pds/index.php/Main/CourseSchedule)
